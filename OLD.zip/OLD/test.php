<?php

include_once('fonctions.php');
 /*Récupération de la dernière page*/
echo(nl2br("Page 1 sur " . getLastAnnuaireMairiePage()));



?>
<?php
/**/
require_once __DIR__ . '/Classes/local_orga.php';
require_once __DIR__ . '/Classes/process.php';

function response($status, $status_message, $data)
{
    header("HTTP/1.1 ".$status);
    //header("Content-Type:application/json;charset=utf-8", false);
    $response['status']=$status;
    $response['status_message']=$status_message;
    $response['data']=$data;
    $json_response = json_encode($response, JSON_UNESCAPED_UNICODE);
    echo $json_response;
    die();
}


$process = new Process();
//On récupère l'id du nouveau process
$process->getCurrentProcess();
$current_process = $process->__get("current_process");
//echo(nl2br("Process actuel : " . $current_process . "\n"));


$current_process = 242;
$Local_Orga = new Local_Orga();
$data = $Local_Orga->getJSONMap($current_process);

response(200, 'data_for_map_creation', $data);

?>
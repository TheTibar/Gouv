<?php
/**/
require_once __DIR__ . '/Classes/local_orga.php';
require_once __DIR__ . '/Classes/process.php';

$process = new Process();
//On récupère l'id du nouveau process
$process->getCurrentProcess();
$current_process = $process->__get("current_process");
echo(nl2br("Process actuel : " . $current_process . "\n"));

echo(nl2br("ne pas oublier de créer le niveau -1 avec cette requête : \n insert into gouv_local_orga \n
(theme, id, remote_id, link, label, father_id, process_id) \n
values \n
('Point central', 99999, 99999, -1, 'Racine', 'Point central', 0, '$current_process'); \n"));

echo("ne pas oublier de mette à jour le niveau 0 avec cette requête : \n update gouv_local_orga \n
set father_id = 99999 \n
where father_id = 0 and level = 0 and process_id = $current_process; \n");
/**/


$Local_Orga = new Local_Orga();
$Local_Orga->get3dJSON($current_process);

?>